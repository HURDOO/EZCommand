package org.fxmisc.richtext.demo.brackethighlighter;

public interface TextInsertionListener {

    void codeInserted(int start, int end, String text);

}
